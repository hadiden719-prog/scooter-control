# Platform setup checklist

## Android
- Declare BLUETOOTH_SCAN and BLUETOOTH_CONNECT for Android 12+.
- Handle runtime permission requests and Bluetooth adapter state.
- For older Android versions, apply the location permission requirements appropriate to the target SDK and BLE plugin.
- Test on real devices across Android API levels.
- Do not request background location unless genuinely required.

## iOS
- Add NSBluetoothAlwaysUsageDescription to Info.plist.
- Test CoreBluetooth behavior on physical iPhones.
- Do not enable bluetooth-central background mode unless background BLE is a real product requirement.
- Plan for iOS restrictions on long-running background operations and OTA sessions.

## Release
- Keep signing keys outside the repository.
- Use reproducible versioned builds.
- Publish checksums and signed release artifacts.

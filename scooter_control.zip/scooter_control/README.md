# Scooter Control

Cross-platform Flutter foundation for owner-operated Xiaomi, Ninebot, Segway and NIU scooters.

## Current scope

- Flutter Android/iOS app skeleton
- BLE scan/connect/GATT transport adapter using FlutterBluePlus
- Domain-level BLE transport contract
- Initial model-profile registry
- Safe profile-only adapters
- Dark crimson UI and device discovery screen

## Important implementation boundary

The included profiles are **discovery candidates**, not proof of device identity or complete protocol support. Name-based matching is only a first-pass hint. Production identification must validate manufacturer/service data, GATT layout, model identifiers, hardware revision and firmware/bootloader data.

No firmware flashing, speed unlocking, write characteristics, authentication bypass or OTA commands are implemented. OTA must be added only for an exact model + controller board + BLE board + firmware combination with a documented and tested procedure. Unknown combinations must remain read-only or unsupported.

## Setup

1. Install Flutter stable and platform toolchains.
2. Run `flutter create --platforms=android,ios .` if platform folders are absent.
3. Run `flutter pub get`.
4. Configure Android permissions in `android/app/src/main/AndroidManifest.xml`.
5. Configure iOS Bluetooth usage descriptions in `ios/Runner/Info.plist`.
6. Run on a physical device. BLE scanning is not reliably testable in simulators.

## Platform permissions

Android permissions vary by OS level. For Android 12+ configure `BLUETOOTH_SCAN` and `BLUETOOTH_CONNECT`; for older versions configure the appropriate location permission required by the target SDK and plugin. Avoid `neverForLocation` unless its implications for scan results are understood.

iOS requires `NSBluetoothAlwaysUsageDescription` in `Info.plist`. Background BLE modes should only be enabled if the app genuinely needs them.

## Model references

- ScooterHacking Wiki: https://wiki.scooterhacking.org/doku.php?id=start
- Xiaomi M365 family: https://wiki.scooterhacking.org/doku.php?id=mi365
- Ninebot crypto research: https://github.com/scooterhacking/NinebotCrypto
- Xiaomi 4 Pro 2nd Gen protocol research: https://github.com/mehesbalazs/xiaomi-scooter-4-pro-2

## Next engineering milestones

1. Add robust manufacturer-data and GATT fingerprint identification.
2. Implement read-only telemetry decoders per exact profile.
3. Add device connection lifecycle and reconnect handling.
4. Add test fixtures and recorded BLE packet tests.
5. Implement secure firmware metadata/signature verification.
6. Design a model-specific OTA interface only after protocol and recovery validation.

import 'dart:async';
import 'package:flutter/material.dart';
import '../../data/ble/flutter_blue_plus_transport.dart';
import '../../data/adapters/adapter_registry.dart';
import '../../domain/models/scooter_models.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});
  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  late final FlutterBluePlusTransport transport;
  final registry = AdapterRegistry();
  StreamSubscription<List<BleDeviceInfo>>? subscription;
  List<BleDeviceInfo> devices = [];
  bool scanning = false;

  @override
  void initState() {
    super.initState();
    transport = FlutterBluePlusTransport();
    subscription = transport.scanResults.listen((results) {
      if (mounted) setState(() => devices = results);
    });
  }

  Future<void> scan() async {
    setState(() => scanning = true);
    try {
      await transport.startScan(timeout: const Duration(seconds: 12));
      await Future<void>.delayed(const Duration(seconds: 12));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('BLE scan failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => scanning = false);
    }
  }

  @override
  void dispose() {
    subscription?.cancel();
    transport.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('DEVICE DISCOVERY')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: scanning ? null : scan,
      icon: const Icon(Icons.bluetooth_searching),
      label: Text(scanning ? 'Scanning...' : 'Start scan'),
    ),
    body: ListView.builder(
      itemCount: devices.length,
      itemBuilder: (context, index) {
        final device = devices[index];
        final adapter = registry.findCandidate(device);
        return ListTile(
          leading: const Icon(Icons.electric_scooter, color: Color(0xFFFF5265)),
          title: Text(device.name.isEmpty ? 'Unnamed BLE device' : device.name),
          subtitle: Text(
            '${device.remoteId} · RSSI ${device.rssi} dBm\n'
            '${adapter?.profile.displayName ?? "Unknown / unsupported profile"}',
          ),
          isThreeLine: true,
          trailing: Icon(
            adapter == null ? Icons.help_outline : Icons.verified_user_outlined,
            color: adapter == null ? Colors.orange : Colors.green,
          ),
          onTap: adapter == null ? null : () async {
            try {
              await adapter.connect(transport, device.remoteId);
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Connected to ${adapter.profile.displayName}. Identity still requires protocol validation.')),
              );
            } catch (e) {
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Connection failed: $e')),
              );
            }
          },
        );
      },
    ),
  );
}

import 'package:flutter/material.dart';
import '../scanner/scanner_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SCOOTER CONTROL')),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.electric_scooter, size: 76, color: Color(0xFFFF3048)),
            const SizedBox(height: 18),
            const Text('Your scooter. Your data.',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Discover supported BLE devices and inspect their model profiles.',
              textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ScannerScreen()),
              ),
              icon: const Icon(Icons.bluetooth_searching),
              label: const Text('SCAN FOR SCOOTERS'),
            ),
          ],
        ),
      ),
    ),
  );
}

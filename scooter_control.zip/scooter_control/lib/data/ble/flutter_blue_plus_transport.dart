import 'dart:async';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import '../../domain/ble/ble_transport.dart';
import '../../domain/models/scooter_models.dart';

class FlutterBluePlusTransport implements BleTransport {
  final _scanController = StreamController<List<BleDeviceInfo>>.broadcast();
  final _connectionController = StreamController<String?>.broadcast();
  StreamSubscription<List<ScanResult>>? _scanSub;
  BluetoothDevice? _device;

  @override
  Stream<List<BleDeviceInfo>> get scanResults => _scanController.stream;

  @override
  Stream<String?> get connectedDeviceId => _connectionController.stream;

  @override
  Future<void> startScan({Duration timeout = const Duration(seconds: 10)}) async {
    await FlutterBluePlus.startScan(timeout: timeout);
    await _scanSub?.cancel();
    _scanSub = FlutterBluePlus.scanResults.listen((results) {
      final devices = results.map((r) => BleDeviceInfo(
        remoteId: r.device.remoteId.str,
        name: r.advertisementData.advName.isNotEmpty
            ? r.advertisementData.advName
            : r.device.platformName,
        serviceUuids: r.advertisementData.serviceUuids
            .map((u) => u.str.toLowerCase()).toList(),
        manufacturerData: r.advertisementData.manufacturerData,
        rssi: r.rssi,
      )).toList();
      _scanController.add(devices);
    });
  }

  @override
  Future<void> stopScan() async {
    await FlutterBluePlus.stopScan();
    await _scanSub?.cancel();
    _scanSub = null;
  }

  @override
  Future<void> connect(String remoteId) async {
    await stopScan();
    final device = BluetoothDevice.fromId(remoteId);
    await device.connect(timeout: const Duration(seconds: 15));
    _device = device;
    _connectionController.add(remoteId);
  }

  @override
  Future<void> disconnect() async {
    final device = _device;
    if (device != null) await device.disconnect();
    _device = null;
    _connectionController.add(null);
  }

  @override
  Future<List<String>> discoverServiceUuids() async {
    final device = _device;
    if (device == null) throw StateError('No connected scooter');
    final services = await device.discoverServices();
    return services.map((s) => s.serviceUuid.str.toLowerCase()).toList();
  }

  BluetoothDevice get _requireDevice =>
      _device ?? (throw StateError('No connected scooter'));

  @override
  Future<void> write({
    required String serviceUuid,
    required String characteristicUuid,
    required List<int> value,
    bool withoutResponse = false,
  }) async {
    final services = await _requireDevice.discoverServices();
    final service = services.firstWhere(
      (s) => s.serviceUuid.str.toLowerCase() == serviceUuid.toLowerCase(),
      orElse: () => throw StateError('GATT service not found: $serviceUuid'),
    );
    final characteristic = service.characteristics.firstWhere(
      (c) => c.characteristicUuid.str.toLowerCase() == characteristicUuid.toLowerCase(),
      orElse: () => throw StateError('GATT characteristic not found: $characteristicUuid'),
    );
    await characteristic.write(value, withoutResponse: withoutResponse);
  }

  @override
  Stream<List<int>> subscribe({
    required String serviceUuid,
    required String characteristicUuid,
  }) async* {
    final services = await _requireDevice.discoverServices();
    final service = services.firstWhere(
      (s) => s.serviceUuid.str.toLowerCase() == serviceUuid.toLowerCase(),
    );
    final characteristic = service.characteristics.firstWhere(
      (c) => c.characteristicUuid.str.toLowerCase() == characteristicUuid.toLowerCase(),
    );
    await characteristic.setNotifyValue(true);
    yield* characteristic.onValueReceived;
  }

  Future<void> dispose() async {
    await stopScan();
    await disconnect();
    await _scanController.close();
    await _connectionController.close();
  }
}

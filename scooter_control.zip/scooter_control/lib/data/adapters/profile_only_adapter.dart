import '../../domain/adapters/scooter_adapter.dart';
import '../../domain/ble/ble_transport.dart';
import '../../domain/models/capability_profile.dart';
import '../../domain/models/scooter_models.dart';

/// Safe initial adapter: discovery/profile matching only.
/// It intentionally exposes no write or OTA implementation.
class ProfileOnlyAdapter implements ScooterAdapter {
  ProfileOnlyAdapter(this.profile);
  @override
  final ModelProfile profile;

  BleTransport? _transport;

  @override
  bool matches(BleDeviceInfo device) {
    final text = '${device.name} ${device.remoteId}'.toLowerCase();
    return profile.modelAliases.any((alias) => text.contains(alias.toLowerCase()));
  }

  @override
  Future<void> connect(BleTransport transport, String remoteId) async {
    _transport = transport;
    await transport.connect(remoteId);
  }

  @override
  Future<ScooterIdentity> identify() async {
    throw UnimplementedError(
      'Exact identity requires a validated ${profile.id} protocol decoder.',
    );
  }

  @override
  Stream<ScooterTelemetry> get telemetry =>
      const Stream<ScooterTelemetry>.empty();

  @override
  Future<Set<ScooterCapability>> capabilities() async =>
      profile.capabilities;

  @override
  Future<void> disconnect() async {
    await _transport?.disconnect();
    _transport = null;
  }
}

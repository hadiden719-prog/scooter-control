import '../../domain/models/capability_profile.dart';
import '../../domain/models/scooter_models.dart';

const commonRead = <ScooterCapability>{
  ScooterCapability.telemetry,
  ScooterCapability.diagnostics,
};

const modelProfiles = <ModelProfile>[
  ModelProfile(
    id: 'xiaomi-m365',
    brand: ScooterBrand.xiaomi,
    displayName: 'Xiaomi M365',
    modelAliases: ['m365'],
    capabilities: commonRead,
    protocolReference: 'https://wiki.scooterhacking.org/doku.php?id=mi365',
    notes: 'Legacy M365 profile. Validate controller and BLE board revision.',
  ),
  ModelProfile(
    id: 'xiaomi-pro2',
    brand: ScooterBrand.xiaomi,
    displayName: 'Xiaomi M365 Pro 2',
    modelAliases: ['pro2', 'm365 pro 2'],
    capabilities: commonRead,
    protocolReference: 'https://wiki.scooterhacking.org/doku.php?id=mi365',
    notes: 'BLE generation and controller revision must be checked independently.',
  ),
  ModelProfile(
    id: 'ninebot-g30',
    brand: ScooterBrand.ninebot,
    displayName: 'Ninebot Max G30',
    modelAliases: ['g30', 'ninebot max'],
    capabilities: commonRead,
    protocolReference: 'https://wiki.scooterhacking.org/doku.php?id=start',
    notes: 'G30 family; do not assume all Max variants share the same board.',
  ),
  ModelProfile(
    id: 'ninebot-f-series',
    brand: ScooterBrand.ninebot,
    displayName: 'Ninebot F-Series',
    modelAliases: ['f20', 'f25', 'f30', 'f40', 'ninebot f'],
    capabilities: commonRead,
    protocolReference: 'https://wiki.scooterhacking.org/doku.php?id=start',
    notes: 'BLE307 is documented for some F-series devices; verify exact firmware.',
  ),
  ModelProfile(
    id: 'xiaomi-4-series',
    brand: ScooterBrand.xiaomi,
    displayName: 'Xiaomi Electric Scooter 4 / 4 Pro',
    modelAliases: ['xiaomi scooter 4', '4 pro'],
    capabilities: {},
    protocolReference: 'https://github.com/mehesbalazs/xiaomi-scooter-4-pro-2',
    notes: 'Treat generations separately. Newer variants may use authenticated encrypted MIoT.',
  ),
  ModelProfile(
    id: 'segway-gt-series',
    brand: ScooterBrand.segway,
    displayName: 'Segway GT-Series',
    modelAliases: ['gt1', 'gt2', 'segway gt'],
    capabilities: {},
    protocolReference: 'https://wiki.scooterhacking.org/doku.php?id=start',
    notes: 'Research-only profile; no assumed compatibility with Ninebot G30.',
  ),
  ModelProfile(
    id: 'niu-kqi-series',
    brand: ScooterBrand.niu,
    displayName: 'NIU KQi-Series',
    modelAliases: ['kqi', 'niu'],
    capabilities: {},
    protocolReference: 'https://github.com/',
    notes: 'Research-only profile. Do not infer GATT protocol from advertising name.',
  ),
];

import '../../domain/adapters/scooter_adapter.dart';
import '../../domain/models/scooter_models.dart';
import 'model_profiles.dart';
import 'profile_only_adapter.dart';

class AdapterRegistry {
  List<ScooterAdapter> createAdapters() =>
      modelProfiles.map(ProfileOnlyAdapter.new).toList();

  ScooterAdapter? findCandidate(BleDeviceInfo device) {
    for (final adapter in createAdapters()) {
      if (adapter.matches(device)) return adapter;
    }
    return null;
  }
}

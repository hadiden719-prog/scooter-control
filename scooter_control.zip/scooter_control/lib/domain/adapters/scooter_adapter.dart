import '../ble/ble_transport.dart';
import '../models/capability_profile.dart';
import '../models/scooter_models.dart';

abstract interface class ScooterAdapter {
  ModelProfile get profile;
  bool matches(BleDeviceInfo device);
  Future<void> connect(BleTransport transport, String remoteId);
  Future<ScooterIdentity> identify();
  Stream<ScooterTelemetry> get telemetry;
  Future<Set<ScooterCapability>> capabilities();
  Future<void> disconnect();
}

enum ScooterBrand { xiaomi, ninebot, segway, niu, unknown }
enum DriveMode { eco, drive, sport }

enum ScooterCapability {
  telemetry,
  diagnostics,
  driveModeRead,
  driveModeWrite,
  speedLimitRead,
  speedLimitWrite,
  firmwareRead,
  firmwareBackup,
  firmwareOta,
}

class ScooterIdentity {
  const ScooterIdentity({
    required this.brand,
    required this.model,
    required this.hardwareRevision,
    required this.firmwareVersion,
    required this.deviceId,
    this.bootloaderVersion,
  });

  final ScooterBrand brand;
  final String model;
  final String hardwareRevision;
  final String firmwareVersion;
  final String deviceId;
  final String? bootloaderVersion;
}

class ScooterTelemetry {
  const ScooterTelemetry({
    required this.speedKmh,
    required this.batteryPercent,
    required this.temperatureC,
    required this.odometerKm,
    required this.errorCodes,
    required this.timestamp,
  });

  final double speedKmh;
  final int batteryPercent;
  final double temperatureC;
  final double odometerKm;
  final List<String> errorCodes;
  final DateTime timestamp;

  double get speedMph => speedKmh * 0.621371;
  double get odometerMiles => odometerKm * 0.621371;
  double get temperatureF => temperatureC * 9 / 5 + 32;
}

class BleDeviceInfo {
  const BleDeviceInfo({
    required this.remoteId,
    required this.name,
    required this.serviceUuids,
    required this.manufacturerData,
    required this.rssi,
  });

  final String remoteId;
  final String name;
  final List<String> serviceUuids;
  final Map<int, List<int>> manufacturerData;
  final int rssi;
}

import 'scooter_models.dart';

class ModelProfile {
  const ModelProfile({
    required this.id,
    required this.brand,
    required this.displayName,
    required this.modelAliases,
    required this.capabilities,
    required this.protocolReference,
    this.otaStatus = OtaSupport.notImplemented,
    this.notes = '',
  });

  final String id;
  final ScooterBrand brand;
  final String displayName;
  final List<String> modelAliases;
  final Set<ScooterCapability> capabilities;
  final String protocolReference;
  final OtaSupport otaStatus;
  final String notes;
}

enum OtaSupport {
  notImplemented,
  researchRequired,
  documentedButNotImplemented,
  validatedForExactHardware,
}

import '../models/scooter_models.dart';

abstract interface class BleTransport {
  Stream<List<BleDeviceInfo>> get scanResults;
  Stream<String?> get connectedDeviceId;

  Future<void> startScan({Duration timeout = const Duration(seconds: 10)});
  Future<void> stopScan();
  Future<void> connect(String remoteId);
  Future<void> disconnect();
  Future<List<String>> discoverServiceUuids();
  Future<void> write({
    required String serviceUuid,
    required String characteristicUuid,
    required List<int> value,
    bool withoutResponse = false,
  });
  Stream<List<int>> subscribe({
    required String serviceUuid,
    required String characteristicUuid,
  });
}

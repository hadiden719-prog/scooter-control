import 'package:flutter/material.dart';
import 'features/home/home_screen.dart';

class ScooterControlApp extends StatelessWidget {
  const ScooterControlApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Scooter Control',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF080808),
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFFFF3048),
        secondary: Color(0xFFFF6677),
        surface: Color(0xFF171717),
      ),
      useMaterial3: true,
    ),
    home: const HomeScreen(),
  );
}
